from flask import Flask, render_template, request, Response, jsonify
import requests
import json
from flask_cors import CORS
import pyttsx3
engine = pyttsx3.init()
engine.setProperty('rate', 150)  
engine.setProperty('volume', 1.0) 
app = Flask(__name__)
CORS(app)
OLLAMA_URL = "http://127.0.0.1:11434/api/generate"

def stream_ollama(prompt, model="deepseek-r1"):
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": True
    }

    with requests.post(OLLAMA_URL, json=payload, stream=True) as response:
        if response.status_code == 200:
            text_to_speak = []  # Collect text responses
            
            for line in response.iter_lines():
                if line:
                    decoded_line = json.loads(line)
                    text = decoded_line.get('response', '').strip()

                    # Debugging: Print full API response
                    print(f"Full API Response: {decoded_line}")

                    # Ignore "<think>" and non-verbal responses
                    if text and not text.startswith("<"):
                        print(f"Speaking: {text}")  # Debugging
                        yield f"{text}\n"

                        text_to_speak.append(text)

            # Speak collected text after streaming
            if text_to_speak:
                engine.say(" ".join(text_to_speak))
                engine.runAndWait()  # Run only once at the end

        else:
            yield f"Error: {response.status_code}, {response.text}\n"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "")
    
    if not user_message:
        return jsonify({"response": "Please enter a message."})

    return Response(stream_ollama(user_message), content_type="text/plain")


if __name__ == "__main__":
    app.run(debug=True, threaded=True)
